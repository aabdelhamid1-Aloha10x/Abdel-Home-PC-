# Crewzero

AI agents that run the whole company. A product of Masar AI Inc. (Delaware C corporation).
Solo founder + AI, built in public.

## Start here (owner)
1. Create an empty **private** GitHub repo named `crewzero`.
2. Unzip this folder and push its contents to the repo root (or upload the files on github.com).
3. Open the repo in **Codex** (cloud or CLI). Codex reads `AGENTS.md` automatically.
4. Never paste secrets into chat or files. Real values go in `.env.local` (local) and the Cloudflare / Supabase / Trigger.dev secret stores. `.env.example` lists the names.

## Build order: give Codex one prompt at a time
| Order | Prompt | Phase |
|---|---|---|
| 1 | `prompts/00_repo_setup_and_waitlist.md` | Week 0: monorepo + crewzero.ai waitlist |
| 2 | `prompts/01_foundation.md` | Phase 1: database, auth, credits, renderer, jobs |
| 3 | `prompts/02_aha_onboarding.md` | Phase 2: idea -> plan + live preview in 20 min |
| 4 | `prompts/03_launch_and_money.md` | Phase 3: billing, domains, Connect, email |
| 5 | `prompts/04_autopilot_core.md` | Phase 4: orchestrator, coach, engines, dashboard |
| 6 | `prompts/05_onward.md` | Phases 5-8 (to be expanded) |

Message to send Codex each time:
> Read AGENTS.md and docs/. Do prompts/0X_....md only. Follow the definition of done. Run and verify; tell me what you could not verify.

After each step: read the report, click through what it says it verified, then move to the next prompt.

## Docs
| File | What it is |
|---|---|
| `docs/00_MASTER_SPEC.md` | Product: positioning, agents, coach, engines, creators, pricing (test only), contest, compliance |
| `docs/01_INFRASTRUCTURE.md` | Stack, hosting, tenancy, agent runtime, data model, approvals |
| `docs/02_BUILD_QUEUE.md` | Week 0 next steps and phases 1-8 with exit criteria |
| `docs/03_OWNER_DECISIONS.md` | Decided items and open questions |
| `docs/04_COST_ANALYSIS.md` | Cost comparisons and credit testing plan |
| `docs/05_LAUNCH_GTM_FUNDRAISING.md` | Launch, viral loops, fundraising |

Note: the product's own agents call Claude, OpenAI, Grok, Gemini and Perplexity through their APIs (pay per use), separate from any Claude or ChatGPT subscription used for building.
